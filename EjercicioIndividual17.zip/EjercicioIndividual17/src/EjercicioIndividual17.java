import java.util.Scanner;

public class EjercicioIndividual17{


    public static void main(String [] args){

        Scanner leer = new Scanner(System.in);

        String palabra = "";

        do{
            System.out.println("Ingrese la frase que desea analizar");
            palabra = leer.nextLine();
        }
        while(palabra.isEmpty()); {

        }

        int vocales = 0;
        int consonantes = 0;

        for (int i = 0; i < palabra.length(); i++) {

            char c = palabra.charAt(i);
            System.out.println(c);

            if (Character.isLetter(c)){
                c = Character.toLowerCase(c);
                if (c =='a' || c == 'e' || c == 'i' || c == 'o' || c == 'u'){
                    vocales = vocales + 1;
                }else{
                    consonantes = consonantes + 1;
                }
            }
        }
        System.out.println("La frase tiene " + vocales + "  vocales y "+consonantes+"  consonantes");
    }
}
